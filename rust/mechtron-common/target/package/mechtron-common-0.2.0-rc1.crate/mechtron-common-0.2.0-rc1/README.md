Common code used by Mechtron host and guest alike.
